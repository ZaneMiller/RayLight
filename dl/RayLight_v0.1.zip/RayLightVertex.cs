﻿using UnityEngine;
using System.Collections;

public class RayLightVertex : MonoBehaviour {
	public bool useChildren = false;
}
